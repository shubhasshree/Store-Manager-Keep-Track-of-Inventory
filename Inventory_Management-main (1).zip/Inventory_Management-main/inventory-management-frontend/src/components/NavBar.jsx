const NavBar = () => {
    return (
      <nav className="bg-green-800 py-4">
        <div className="mx-auto px-4">
          <div className="flex justify-between">
            <div className="flex items-center w-1/3">
            <a href="/" className="ml-6 bg-green-800 rounded p-1 text-gray-300 hover:text-white"
            style={{ fontFamily: 'Times New Roman, serif' }}>
                Home
              </a>
              <a href="/cart" className="ml-6 bg-green-800 rounded p-1 text-gray-300 hover:text-white"
              style={{ fontFamily: 'Times New Roman, serif' }}>
                Cart
              </a>
              <a href="/inventory" className="ml-6 bg-green-800 rounded p-1 text-gray-300 hover:text-white"
              style={{ fontFamily: 'Times New Roman, serif' }}>
                Inventory
              </a>
              <a href="/sales" className="ml-6 bg-green-800 rounded p-1 text-gray-300 hover:text-white"style={{ fontFamily: 'Times New Roman, serif' }}>
                Sales
              </a>
              <a href="/add-product" className="ml-6 bg-green-800 rounded p-1 text-gray-300 hover:text-white"style={{ fontFamily: 'Times New Roman, serif' }}>
                Add Product
              </a>
            </div>
            <div className="flex items-center w-1/3 justify-center">
              <h2 className="text-white text-lg font-bold "
              style={{ fontFamily: 'Times New Roman, serif' }}>RetailReady!</h2>
              <img className="w-[60px] h-[60px] mx-2" src="/inventoryLogo.jpg" alt="LOGO" />
            </div>
          </div>
        </div>
      </nav>
    );
  };
  
export default NavBar;
  